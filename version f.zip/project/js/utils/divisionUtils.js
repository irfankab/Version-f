// Specialized utilities for division operations
export function generateDivisionNumbers(difficulty) {
    // Generate numbers that divide evenly or with max 2 decimal places
    const ranges = {
        easy: { min: 1, max: 20 },
        medium: { min: 1, max: 50 },
        hard: { min: 1, max: 100 }
    };

    const range = ranges[difficulty] || ranges.easy;
    const dividend = Math.floor(Math.random() * (range.max - range.min + 1)) + range.min;
    
    // Generate divisors that give reasonable answers (1-10 for easy, 1-20 for others)
    const maxDivisor = difficulty === 'easy' ? 10 : 20;
    const divisor = Math.floor(Math.random() * maxDivisor) + 1;

    return {
        dividend,
        divisor,
        // Pre-calculate the answer for validation
        answer: Number((dividend / divisor).toFixed(2))
    };
}

export function formatDivisionAnswer(answer) {
    // Handle perfect divisions vs decimal answers
    return Number.isInteger(answer) ? answer : Number(answer.toFixed(2));
}

export function generateDivisionOptions(correctAnswer) {
    const options = new Set([correctAnswer]);
    
    while (options.size < 4) {
        let wrongAnswer;
        const randomChoice = Math.random();
        
        if (randomChoice < 0.3) {
            // Off by one error
            wrongAnswer = formatDivisionAnswer(correctAnswer + (Math.random() < 0.5 ? 1 : -1));
        } else if (randomChoice < 0.6) {
            // Decimal place error
            wrongAnswer = formatDivisionAnswer(correctAnswer + (Math.random() < 0.5 ? 0.1 : -0.1));
        } else {
            // Random close number
            const variation = correctAnswer * (0.1 + Math.random() * 0.2);
            wrongAnswer = formatDivisionAnswer(correctAnswer + (Math.random() < 0.5 ? variation : -variation));
        }
        
        if (wrongAnswer > 0) {
            options.add(wrongAnswer);
        }
    }
    
    return Array.from(options).sort((a, b) => a - b);
}