// Difficulty settings and management
const DIFFICULTY_RANGES = {
    easy: { min: 1, max: 10 },
    medium: { min: 1, max: 50 },
    hard: { min: 1, max: 100 }
};

export function getNumberRange(level) {
    return DIFFICULTY_RANGES[level] || DIFFICULTY_RANGES.easy;
}