import { generateDivisionNumbers, formatDivisionAnswer } from './divisionUtils.js';

export function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

export function calculateAnswer(num1, num2, operation) {
    switch (operation) {
        case '+': return num1 + num2;
        case '-': return num1 - num2;
        case '×': return num1 * num2;
        case '÷': return formatDivisionAnswer(num1 / num2);
    }
}