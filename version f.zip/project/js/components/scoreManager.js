export class ScoreManager {
    constructor(initialAttempts = 3) {
        this.score = 0;
        this.attempts = initialAttempts;
    }

    addPoint() {
        this.score++;
        return this.score;
    }

    removeAttempt() {
        this.attempts--;
        return this.attempts;
    }

    reset() {
        this.score = 0;
        this.attempts = 3;
    }

    hasAttemptsLeft() {
        return this.attempts > 0;
    }

    getScore() {
        return this.score;
    }

    getAttempts() {
        return this.attempts;
    }
}