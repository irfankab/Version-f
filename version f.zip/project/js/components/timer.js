export class GameTimer {
    constructor(totalTime, onTick, onComplete) {
        this.totalTime = totalTime;
        this.timeLeft = totalTime;
        this.onTick = onTick;
        this.onComplete = onComplete;
        this.timerId = null;
    }

    start() {
        this.stop();
        this.timerId = setInterval(() => {
            this.timeLeft--;
            this.onTick(this.timeLeft);
            
            if (this.timeLeft <= 0) {
                this.stop();
                this.onComplete();
            }
        }, 1000);
    }

    stop() {
        if (this.timerId) {
            clearInterval(this.timerId);
            this.timerId = null;
        }
    }

    reset() {
        this.timeLeft = this.totalTime;
        this.stop();
    }
}