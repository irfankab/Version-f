import { getRandomInt } from '../utils/mathUtils.js';

export function generateOptions(correctAnswer) {
    const options = new Set([correctAnswer]);
    const range = Math.max(5, Math.abs(correctAnswer * 0.2)); // Dynamic range based on answer

    while (options.size < 4) {
        const offset = getRandomInt(-range, range);
        const wrongAnswer = Number((correctAnswer + offset).toFixed(2));
        if (wrongAnswer !== correctAnswer) {
            options.add(wrongAnswer);
        }
    }

    return Array.from(options).sort(() => Math.random() - 0.5);
}