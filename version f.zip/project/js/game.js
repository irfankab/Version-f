// Update the generateQuestion method in the MathGame class
    generateQuestion() {
        const range = getNumberRange(this.difficulty);
        let num1, num2;

        if (this.operation === '÷') {
            const numbers = generateDivisionNumbers(this.difficulty);
            num1 = numbers.dividend;
            num2 = numbers.divisor;
            this.correctAnswer = numbers.answer;
        } else {
            num1 = getRandomInt(range.min, range.max);
            num2 = getRandomInt(range.min, range.max);
            this.correctAnswer = calculateAnswer(num1, num2, this.operation);
        }
        
        const questionElement = document.getElementById('question');
        questionElement.textContent = `What is ${num1} ${this.operation} ${num2}?`;
        Animations.fadeIn(questionElement);

        this.displayOptions(this.correctAnswer);
    }